import React from 'react';

const Sorter = () => {
  return (
    <div className= "sorter">
      <h3>Sort by:</h3>
      
    </div>
  );
};

export default Sorter;