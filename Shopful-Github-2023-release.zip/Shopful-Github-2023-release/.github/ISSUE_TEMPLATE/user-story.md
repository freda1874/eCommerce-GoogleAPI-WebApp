---
name: User Story
about: Document a User Story
title: As a <REPLACE>, I want to <REPLACE>, so that <REPLACE>
labels: Epic
assignees: ''

---

# Details:

# Acceptance Criteria for User Story:
_For example info about Acceptance Criteria, see (https://agileforgrowth.com/blog/acceptance-criteria-checklist/)_
* Item 1
* Item 2

# Test Scenario for User Story:
_Test Scenario gives the idea of what we have to test. Test Scenario is like a high-level test case.(https://www.softwaretestingmaterial.com/test-scenario-vs-test-case/)_
* Item 1
* Item 2
